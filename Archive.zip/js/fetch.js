window.videoId="";
window.liveUrl="";

const getData_Server1 = () =>{
  fetch('https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCwNsZ7DTlA8vhhqqCmwG-aw&eventType=live&type=video&key=AIzaSyCbNWFZfJILsnNoWFSXOkZogk2Yar_1-WA')
    .then(response => {
      return response.json();
    })
  .then(responseData => {
          console.log(responseData);
          videoId = responseData.items[0].id.videoId;
        });

    if(videoId==undefined)
    {
      videoId='_1uWeph1zEE';
    }
    console.log(videoId);
    liveUrl = 'https://www.youtube.com/watch?v='+videoId;
};

const getData_Server2 = () =>{
  fetch('https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCwNsZ7DTlA8vhhqqCmwG-aw&eventType=live&type=video&key=AIzaSyC1At80HIfIDT4kh95LfSPJSle7jxRtTpw')
    .then(response => {
      return response.json();
    })
  .then(responseData => {
          console.log(responseData);
          window.videoId = responseData.items[0].id.videoId;
        });
        console.log(window.videoId);
    if(window.videoId==undefined)
    {
      window.videoId='_1uWeph1zEE';
    }

    window.liveUrl = 'https://www.youtube.com/watch?v='+window.videoId;
};
